# Add an environment variable to a relay and deploy it

Document ID: DG-RELAY-101-G. Version: 3.0.

Give the relay the token your application expects, from the Lattice Cloud console, and deploy the change. Fictional sample written for this portfolio: the console and the service are invented.

## Before you start

- You have the Developer role in the project.
- You have the token your application expects in the Authorization header.

**Warning**: A value is stored encrypted and never shown again after you save it. Keep it in your password manager as well.

## Steps

1. Open the relay, and then select the Configuration tab.

   The tab lists every environment variable with the date it was last set. Values other than the target URL are never shown.

   ![Step 1: Open the relay, and then select the Configuration tab](images/step-01.png)

2. Check the target URL.

   Select Edit if your application's address has changed. The relay posts every delivery to it.

   ![Step 2: Check the target URL](images/step-02.png)

3. Select Add on the empty row, and then enter the name and the value.

   Choose the environments the value applies to. Reference it in relay.yaml as ${RELAY_TARGET_TOKEN}.

   ![Step 3: Select Add on the empty row, and then enter the name and the value](images/step-03.png)

4. Select Deploy changes.

   A changed variable takes effect at the next deployment, not before.

   ![Step 4: Select Deploy changes](images/step-04.png)

5. Check that the deployment is live and the health check passed.

   The new deployment is at the top of the list. A failed health check keeps the previous deployment serving traffic.

   ![Step 5: Check that the deployment is live and the health check passed](images/step-05.png)

## Check your work

The deployment shows Live with a passing health check, and the variable's row shows today's date under Last set.
