# Schedule a report for automatic delivery

Document ID: TR-BR-007-G. Version: 1.0.

Send a report to the people who need it every week or every month, without opening Beacon Reports on the day. Fictional sample written for this portfolio: the application is invented.

## Before you start

- You can open the report you want to send.
- You have the recipients' email addresses.

## Steps

1. Open the report, and then select Schedule.

   The schedule dialog opens.

   ![Step 1: Open the report, and then select Schedule](images/step-01.png)

2. Enter each recipient and press Enter.

   Each address appears as a chip under the field. Recipients don't need a Beacon account.

   ![Step 2: Enter each recipient and press Enter](images/step-02.png)

3. Choose how often, the day, and the time.

   The time is shown in your time zone. The report uses the data available at that moment.

   ![Step 3: Choose how often, the day, and the time](images/step-03.png)

4. Choose the format, and then select Preview.

   PDF for a report people read, Spreadsheet for one they work with. The preview shows the subject, the attachment's name and the recipients.

   ![Step 4: Choose the format, and then select Preview](images/step-04.png)

5. Select Save schedule.

   The dialog closes and a message names the next delivery.

   ![Step 5: Select Save schedule](images/step-05.png)

6. Check the schedule on the Schedules tab.

   Select Edit to change it or Pause to stop it without deleting it.

   ![Step 6: Check the schedule on the Schedules tab](images/step-06.png)

## Check your work

A message confirms the schedule and names the next delivery, and the report's Schedules tab lists it.
