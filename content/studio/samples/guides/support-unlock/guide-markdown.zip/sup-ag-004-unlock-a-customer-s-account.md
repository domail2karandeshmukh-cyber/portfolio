# Unlock a customer's account

Document ID: SUP-AG-004. Version: 2.0.

Internal procedure for support agents of Ledgerly: a customer is locked out and can't wait for the lock to lift. Verify who you're talking to before you change anything. Fictional sample written for this portfolio.

## Before you start

- The customer has opened a ticket and is in the conversation with you.
- You have the Support agent role in the support console.

**Warning**: Never unlock on the request of someone who isn't the account holder or an administrator of the company, however urgent the request sounds.

## Steps

1. Find the account by its email address.

   The customer record opens with the ticket beside it.

   ![Step 1: Find the account by its email address](images/step-01.png)

2. Check that the customer is verified in this conversation.

   The green banner names the method and the time. Without it, send a verification code first.

   ![Step 2: Check that the customer is verified in this conversation](images/step-02.png)

3. Review the recent sign-in attempts.

   Attempts from the customer's usual location and device point to a mistyped password. Attempts from elsewhere mean you reset the password instead of unlocking.

   ![Step 3: Review the recent sign-in attempts](images/step-03.png)

4. Select Unlock, or send a reset link if the customer isn't sure of the password.

   Enter the ticket number as the reason. A reset link unlocks the account when it's used.

   ![Step 4: Select Unlock, or send a reset link if the customer isn't sure of the password](images/step-04.png)

5. Check the confirmation, and then record what you did in the ticket.

   The customer receives an email that support unlocked the account.

   ![Step 5: Check the confirmation, and then record what you did in the ticket](images/step-05.png)

## Check your work

The Sign-in tab shows Unlocked by with your name and the ticket number, the customer can sign in, and the ticket note says what you did and why.
