# Create a new employee's account

Document ID: IT-PR-031-G. Version: 1.4.

Create the identity a new employee signs in with, in Meridian Identity, and give it the standard access for the department. Fictional sample written for this portfolio.

## Before you start

- The onboarding request is checked and assigned to you.
- You have the Identity administrator role in Meridian Identity.
- You have the HR record open: legal name, start date, manager, department, location and job title.

**Warning**: Enter the attributes exactly as the HR record has them. Payroll, badges and expenses read them from the identity every night.

## Steps

1. Select Users, and then select New user.

   The new-user form opens with the fields the HR record fills.

   ![Step 1: Select Users, and then select New user](images/step-01.png)

2. Enter the name, the start date, and the department.

   The account stays inactive until 08:00 on the start date. Let the system propose the account name: the mailbox and home drive use it.

   ![Step 2: Enter the name, the start date, and the department](images/step-02.png)

3. Check the groups and the licence.

   The department and location groups come from the request. The Standard employee licence creates the mailbox within an hour.

   ![Step 3: Check the groups and the licence](images/step-03.png)

4. Select Create.

   If the page shows Attribute conflict, another account has the same employee number. Don't create a second identity: send the request back to HR.

   ![Step 4: Select Create](images/step-04.png)

5. Pre-register the laptop, and then generate the enrolment link.

   Enter the serial number from the hardware order. Copy the enrolment link into the request's welcome message; it works for fourteen days from the start date.

   ![Step 5: Pre-register the laptop, and then generate the enrolment link](images/step-05.png)

## Check your work

The user's page shows Inactive until the start date, the department and location groups, the Standard employee licence, and a pre-registered device.
