# Record the Readings for a Monthly Pump Inspection

Document ID: MP-PS104-01-G. Version: 1.0.

Record the four inspection readings for a feed pump in the maintenance console, then close the work order. Fictional sample written for this portfolio: it isn't an operating instruction for real equipment.

## Before You Start

- You're signed in to the maintenance console as a technician on the shift the work order is assigned to.
- You have the readings from the local gauges.

**Warning**: Stay outside the guard while the pump runs. Take every reading from a gauge or the console.

## Steps

1. Open the work order and select Record readings.

   The work order lists the four checks and their expected values.

   ![Step 1: Open the work order and select Record readings](images/step-01.png)

2. Enter each reading as shown on the local gauge, then select Save readings.

   Enter the discharge pressure in bar, the bearing temperature in °C, the vibration in mm/s, and whether the seal leaks.

   ![Step 2: Enter each reading as shown on the local gauge, then select Save readings](images/step-02.png)

3. Check that all four results are inside their range, then select Close work order.

   If a result is outside its range, don't close the work order. Report the reading to your supervisor.

   ![Step 3: Check that all four results are inside their range, then select Close work order](images/step-03.png)

## Check Your Work

The work order shows Ready to close, and all four results are inside their expected range.
