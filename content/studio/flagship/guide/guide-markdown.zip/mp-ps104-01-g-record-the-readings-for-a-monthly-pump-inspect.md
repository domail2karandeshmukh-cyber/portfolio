# Record the readings for a monthly pump inspection

Document ID: MP-PS104-01-G. Version: 1.0.

Fictional sample for this portfolio. Record the four inspection readings for a feed pump in the maintenance console, then close the work order.

## Before you start

- You're signed in to the maintenance console as a technician on the shift the work order is assigned to.
- You have the readings from the local gauges.

**Warning**: This is a fictional procedure written to show the studio. Don't use it to maintain real equipment.

## Steps

1. Open the work order and select Record readings.

   The work order lists the four checks and their expected values.

   ![Step 1: Open the work order and select Record readings](images/step-01.png)

2. Enter each reading as shown on the local gauge, then select Save readings.

   Enter the discharge pressure in bar, the bearing temperature in °C, the vibration in mm/s, and whether the seal leaks.

   ![Step 2: Enter each reading as shown on the local gauge, then select Save readings](images/step-02.png)

3. Check that all four results are inside their range, then select Close work order.

   If a result is outside its range, don't close the work order. Report the reading to your supervisor.

   ![Step 3: Check that all four results are inside their range, then select Close work order](images/step-03.png)

## Check your work

The work order shows Ready to close, and all four results are inside their expected range.
